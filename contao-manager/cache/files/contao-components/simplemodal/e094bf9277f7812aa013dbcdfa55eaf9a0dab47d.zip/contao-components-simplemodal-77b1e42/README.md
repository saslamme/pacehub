SimpleModal
===========

This is a customized MooTools [SimpleModal][1] package of the to be integrated
in [Contao Open Source CMS][2].


[1]: http://simplemodal.plasm.it
[2]: https://contao.org
