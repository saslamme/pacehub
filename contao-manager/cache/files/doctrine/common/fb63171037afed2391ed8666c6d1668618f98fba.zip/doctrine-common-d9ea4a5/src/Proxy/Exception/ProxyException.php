<?php

namespace Doctrine\Common\Proxy\Exception;

/**
 * Base exception interface for proxy exceptions.
 *
 * @deprecated The ProxyException interface is deprecated since doctrine/common 3.5.
 */
interface ProxyException
{
}
