This allows you to pass headers that are different between invalidation
requests. If you want to add a header to all requests, such as ``Authorization``,
:ref:`configure the HTTP client <HTTP client configuration>` to use a custom
HTTP client instead.
