<?php

namespace Knp\Bundle\TimeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

final class KnpTimeBundle extends Bundle
{
}
