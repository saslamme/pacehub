# Security Policy

## Reporting a Vulnerability

Please report privately at j.boggiano@seld.be
