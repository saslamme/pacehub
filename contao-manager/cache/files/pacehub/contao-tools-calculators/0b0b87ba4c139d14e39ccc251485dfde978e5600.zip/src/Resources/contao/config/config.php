<?php
// Fallback-Registrierung für Contao 4.13: Frontend-Modultyp einhängen
$GLOBALS['FE_MOD']['miscellaneous']['calc_tools'] = \Pacehub\ToolsCalculatorsBundle\Controller\CalcToolsModuleController::class;
