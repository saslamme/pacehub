<?php
namespace Pacehub\ToolsCalculatorsBundle\Controller;

use Contao\CoreBundle\Controller\FrontendModule\AbstractFrontendModuleController;
use Contao\ModuleModel;
use Contao\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class CalcToolsModuleController extends AbstractFrontendModuleController
{
    protected function getResponse(Template $template, ModuleModel $model, Request $request): Response
    {
        $template->calculatorType = $model->calc_tools_type ?: 'pace';
        $template->defaultDistance = (float) ($model->calc_default_distance ?? 10.0);
        $template->unit = $model->calc_unit ?: 'km';
        $template->showSpeed = (bool) $model->calc_show_speed;

        $GLOBALS['TL_JAVASCRIPT']['tools_calculators'] = 'bundles/toolscalculators/tools.js|static';
        $GLOBALS['TL_CSS']['tools_calculators'] = 'bundles/toolscalculators/tools.css|static';

        return $template->getResponse();
    }
}
