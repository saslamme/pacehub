<?php
$GLOBALS['FE_MOD']['miscellaneous']['calc_tools'] = \Pacehub\ToolsCalculatorsBundle\Controller\CalcToolsModuleController::class;
