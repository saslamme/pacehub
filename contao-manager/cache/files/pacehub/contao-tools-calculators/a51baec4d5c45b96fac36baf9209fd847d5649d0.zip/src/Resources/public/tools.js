(function () {
  function $(root, sel) { return root.querySelector(sel); }
  function $all(root, sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }
  function toSec(hms) {
    if (!hms) return NaN;
    const parts = hms.trim().split(':').map(Number);
    if (parts.some(n => Number.isNaN(n) || n < 0)) return NaN;
    if (parts.length === 3) { const [h, m, s] = parts; return h*3600 + m*60 + s; }
    if (parts.length === 2) { const [m, s] = parts; return m*60 + s; }
    if (parts.length === 1) { return parts[0]*60; }
    return NaN;
  }
  function secToHHMMSS(sec) {
    if (!isFinite(sec) || sec < 0) return '';
    const h = Math.floor(sec/3600);
    const m = Math.floor((sec%3600)/60);
    const s = Math.round(sec%60);
    return [h,m,s].map(v=>String(v).padStart(2,'0')).join(':');
  }
  function secToMMSS(sec) {
    if (!isFinite(sec) || sec <= 0) return '';
    const m = Math.floor(sec/60);
    const s = Math.round(sec%60);
    return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }
  function setError(root, msg) {
    const el = $('.tools-error', root);
    if (!el) return;
    if (msg) { el.textContent = msg; el.hidden = false; }
    else { el.textContent = ''; el.hidden = true; }
  }
  function formatNum(x, digits=2) {
    return (Math.round(x * Math.pow(10,digits)) / Math.pow(10,digits)).toString().replace('.', ',');
  }

  function attachPace(root) {
    const unit = root.getAttribute('data-unit') === 'mi' ? 'mi' : 'km';
    const hasSpeed = root.getAttribute('data-show-speed') === '1';
    const kmPerMi = 1.609344;
    $all(root, '.js-unit-distance').forEach(span => span.textContent = unit);
    $all(root, '.js-unit-speed').forEach(span => span.textContent = unit === 'mi' ? 'mph' : 'km/h');

    const dist = $('[data-field="distance"]', root);
    const time = $('[data-field="time"]', root);
    const pace = $('[data-field="pace"]', root);
    const speed = hasSpeed ? $('[data-field="speed"]', root) : null;
    const def = parseFloat(root.getAttribute('data-default-distance') || '0');
    if (dist && !dist.value && isFinite(def)) dist.value = def;

    function calc() {
      setError(root, '');
      const dUser = parseFloat((dist.value || '').toString().replace(',', '.'));
      if (!isFinite(dUser) || dUser <= 0) { setError(root, 'Bitte eine gültige Distanz eingeben.'); return; }
      const D = unit === 'mi' ? dUser * kmPerMi : dUser;
      const T = toSec((time.value || '').trim());
      const P = toSec((pace.value || '').trim());
      const Vdisp = speed ? parseFloat((speed.value || '').toString().replace(',', '.')) : NaN;

      const have = { T: isFinite(T), P: isFinite(P), V: isFinite(Vdisp) };
      if ((have.T?1:0) + (have.P?1:0) + (have.V?1:0) < 1) {
        setError(root, 'Bitte mindestens zwei Felder ausfüllen.'); return;
      }

      let timeS = T, paceS = P, Vkmh = unit === 'mi' && have.V ? Vdisp*kmPerMi : Vdisp;
      if (have.T && have.P) {
        const pacePerKm = unit === 'mi' ? (paceS / kmPerMi) : paceS;
        if (pacePerKm <= 0) { setError(root, 'Ungültige Eingaben.'); return; }
        Vkmh = 3600 / pacePerKm;
      } else if (have.T && have.V) {
        const pacePerKm = 3600 / Vkmh;
        paceS = unit === 'mi' ? pacePerKm * kmPerMi : pacePerKm;
      } else if (have.P && have.V) {
        const pacePerKm = unit === 'mi' ? (paceS / kmPerMi) : paceS;
        const ok = Math.abs(3600/pacePerKm - Vkmh) < 1e-6;
        if (!ok) { setError(root, 'Pace und Geschwindigkeit passen nicht zusammen.'); return; }
      } else if (have.T) {
        const pacePerKm = timeS / D;
        if (pacePerKm <= 0) { setError(root, 'Ungültige Eingaben.'); return; }
        paceS = unit === 'mi' ? pacePerKm * kmPerMi : pacePerKm;
        Vkmh = 3600 / pacePerKm;
      } else if (have.P) {
        const pacePerKm = unit === 'mi' ? (paceS / kmPerMi) : paceS;
        timeS = D * pacePerKm;
        Vkmh = 3600 / pacePerKm;
      } else if (have.V) {
        const pacePerKm = 3600 / Vkmh;
        paceS = unit === 'mi' ? pacePerKm * kmPerMi : pacePerKm;
        timeS = D * pacePerKm;
      }

      if (!isFinite(paceS) || paceS <= 0) { setError(root, 'Ungültige Pace.'); return; }
      const paceOut = secToMMSS(paceS);
      const Vout = unit === 'mi' ? (Vkmh / kmPerMi) : Vkmh;

      if (pace && !have.P) pace.value = paceOut;
      if (time && !have.T) time.value = secToHHMMSS(timeS);
      if (speed && !have.V) speed.value = formatNum(Vout, 2);
    }

    $('[data-action="calc"]', root).addEventListener('click', calc);
    $('[data-action="reset"]', root).addEventListener('click', function(){
      [dist, time, pace, speed].forEach(function(i){ if(i) i.value=''; });
      setError(root, '');
    });
  }

  function attachBMI(root) {
    const h = $('[data-field="height_cm"]', root);
    const w = $('[data-field="weight_kg"]', root);
    const bmi = $('[data-field="bmi"]', root);
    function calc() {
      setError(root, '');
      const cm = parseFloat((h.value||'').replace(',', '.'));
      const kg = parseFloat((w.value||'').replace(',', '.'));
      if (!isFinite(cm) || cm <= 0 || !isFinite(kg) || kg <= 0) { setError(root, 'Bitte gültige Werte eingeben.'); return; }
      const m = cm / 100;
      const val = kg / (m * m);
      bmi.value = formatNum(val, 1);
    }
    $('[data-action="calc"]', root).addEventListener('click', calc);
    $('[data-action="reset"]', root).addEventListener('click', function(){
      [h,w,bmi].forEach(function(i){ if(i) i.value=''; }); setError(root, '');
    });
  }

  function attachVO2(root) {
    const method = $('[data-field="method"]', root);
    const wrapCooper = $('[data-method="cooper"]', root);
    const wrap15mi = $('[data-method="onepoint5mi"]', root);
    const cooper_m = $('[data-field="cooper_m"]', root);
    const t15 = $('[data-field="onepoint5_time"]', root);
    const out = $('[data-field="vo2max"]', root);

    function switchMethod() {
      const m = method.value;
      wrapCooper.hidden = m !== 'cooper';
      wrap15mi.hidden = m !== 'onepoint5mi';
      out.value = ''; setError(root, '');
    }
    method.addEventListener('change', switchMethod); switchMethod();

    function calc() {
      setError(root, '');
      let val = NaN;
      if (method.value === 'cooper') {
        const d = parseFloat((cooper_m.value||'').replace(',', '.'));
        if (!isFinite(d) || d <= 0) { setError(root, 'Bitte Distanz in Metern angeben.'); return; }
        val = (d - 504.9) / 44.73;
      } else {
        const sec = toSec((t15.value||'').trim());
        if (!isFinite(sec) || sec <= 0) { setError(root, 'Bitte gültige Zeit eingeben.'); return; }
        const min = sec / 60;
        val = 3.5 + (483 / min);
      }
      if (!isFinite(val) || val <= 0) { setError(root, 'Berechnung fehlgeschlagen.'); return; }
      out.value = formatNum(val, 1);
    }
    $('[data-action="calc"]', root).addEventListener('click', calc);
    $('[data-action="reset"]', root).addEventListener('click', function(){
      [cooper_m, t15, out].forEach(function(i){ if(i) i.value=''; }); setError(root, '');
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    $all(document, '[data-calculator]').forEach(function (root) {
      const type = root.getAttribute('data-calculator');
      if (type === 'pace') attachPace(root);
      else if (type === 'bmi') attachBMI(root);
      else if (type === 'vo2max') attachVO2(root);
    });
  });
})();