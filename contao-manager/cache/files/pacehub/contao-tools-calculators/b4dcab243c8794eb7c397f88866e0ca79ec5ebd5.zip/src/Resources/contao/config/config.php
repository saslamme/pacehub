<?php
$GLOBALS['FE_MOD']['miscellaneous']['calc_tools'] = \Pacehub\ToolsCalculatorsBundle\Module\CalcTools::class;
