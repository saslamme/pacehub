(function () {
  function isJQ(obj){ return !!(obj && obj.jquery); }
  function el(node){ return isJQ(node) ? node[0] : node; }
  function qs(root, sel){ var r = el(root); return r ? r.querySelector(sel) : null; }
  function qsa(root, sel){ var r = el(root); return r ? Array.prototype.slice.call(r.querySelectorAll(sel)) : []; }

  function toSecTriple(h,m,s){
    var empty = [h,m,s].every(function(v){ return v==='' || v===null || v===undefined; });
    if (empty) return NaN;
    h = Number(h||0); m = Number(m||0); s = Number(s||0);
    if ([h,m,s].some(function(x){return !isFinite(x) || x<0;})) return NaN;
    return h*3600 + m*60 + s;
  }
  function toSec(hms) {
    if (!hms) return NaN;
    var parts = hms.trim().split(':').map(function(n){ return Number(n); });
    if (parts.some(function(n){ return Number.isNaN(n) || n < 0; })) return NaN;
    if (parts.length === 3) { var h = parts[0], m = parts[1], s = parts[2]; return h*3600 + m*60 + s; }
    if (parts.length === 2) { var m2 = parts[0], s2 = parts[1]; return m2*60 + s2; }
    if (parts.length === 1) { return parts[0]*60; }
    return NaN;
  }
  function secToHHMMSS(sec) {
    if (!isFinite(sec) || sec < 0) return '';
    var h = Math.floor(sec/3600);
    var m = Math.floor((sec%3600)/60);
    var s = Math.round(sec%60);
    function pad(x){ return String(x).padStart(2,'0'); }
    return [pad(h),pad(m),pad(s)].join(':');
  }
  function secToMMSS(sec) {
    if (!isFinite(sec) || sec <= 0) return '';
    var m = Math.floor(sec/60);
    var s = Math.round(sec%60);
    function pad(x){ return String(x).padStart(2,'0'); }
    return pad(m)+':'+pad(s);
  }
  function setError(root, msg) {
    var elr = qs(root, '.tools-error');
    if (!elr) return;
    if (msg) { elr.textContent = msg; elr.hidden = false; }
    else { elr.textContent = ''; elr.hidden = true; }
  }
  function parseNum(val){ return parseFloat((val||'').toString().replace(',','.')); }
  function hasText(el){ return !!(el && String(el.value).trim() !== ''); }

  var GROUPS = [
    { name: 'Kurze Distanzen', items: [
      {label:'400 m', km:0.4},
      {label:'800 m', km:0.8},
      {label:'1 km',  km:1},
      {label:'2 km',  km:2},
      {label:'3 km',  km:3}
    ]},
    { name: 'Mittlere Distanzen', items: [
      {label:'5 km', km:5},
      {label:'10 km', km:10},
      {label:'15 km', km:15},
      {label:'10 Meilen', km:16.09344}
    ]},
    { name: 'Lange Distanzen', items: [
      {label:'20 km', km:20},
      {label:'Halbmarathon', km:21.0975},
      {label:'25 km', km:25},
      {label:'30 km', km:30},
      {label:'Marathon', km:42.195}
    ]},
    { name: 'Ultra Läufe', items: [
      {label:'50 km', km:50},
      {label:'60 km', km:60},
      {label:'80 km', km:80},
      {label:'100 km', km:100}
    ]},
    { name: 'Stunden Läufe', items: [
      {label:'1 Stunde', hours:1},
      {label:'2 Stunden', hours:2},
      {label:'3 Stunden', hours:3},
      {label:'6 Stunden', hours:6},
      {label:'12 Stunden', hours:12},
      {label:'24 Stunden', hours:24}
    ]}
  ];

  function attachPace(root) {
    var unitRadios = qsa(root, 'input[name="unit"][data-field="unit"]');

    var unit = 'km';
    // base ranges from data (stored in km / kmh)
    var baseDistMin  = parseNum(el(root).getAttribute('data-distance-min'))  || 0;
    var baseDistMax  = parseNum(el(root).getAttribute('data-distance-max'))  || 100;
    var baseDistStep = parseNum(el(root).getAttribute('data-distance-step')) || 0.1;

    var baseSpeedMin  = parseNum(el(root).getAttribute('data-speed-min'))  || 0;
    var baseSpeedMax  = parseNum(el(root).getAttribute('data-speed-max'))  || 30;
    var baseSpeedStep = parseNum(el(root).getAttribute('data-speed-step')) || 0.1;

    var kmPerMi = 1.609344;

    var dist  = qs(root, '[data-field="distance"]');
    var distSlider = qs(root, '[data-field="distance_slider"]');
    var hI    = qs(root, '[data-field="time_h"]');
    var mI    = qs(root, '[data-field="time_m"]');
    var sI    = qs(root, '[data-field="time_s"]');
    var pace  = qs(root, '[data-field="pace"]');
    var speed = qs(root, '[data-field="speed"]');
    var speedSlider = qs(root, '[data-field="speed_slider"]');

    var resDistance = qs(root, '.js-res-distance');
    var resTime     = qs(root, '.js-res-time');
    var resPace     = qs(root, '.js-res-pace');
    var resSpeed    = qs(root, '.js-res-speed');
    var presetsWrap = qs(root, '.js-presets');

    function applyRanges(){
      if (dist && distSlider){
        if (unit==='km'){
          dist.min  = String(baseDistMin);  distSlider.min  = String(baseDistMin);
          dist.max  = String(baseDistMax);  distSlider.max  = String(baseDistMax);
          dist.step = String(baseDistStep); distSlider.step = String(baseDistStep);
        } else {
          dist.min  = String((baseDistMin/ kmPerMi).toFixed(2));  distSlider.min  = dist.min;
          dist.max  = String((baseDistMax/ kmPerMi).toFixed(2));  distSlider.max  = dist.max;
          var stepMi = baseDistStep/ kmPerMi;
          dist.step = String(stepMi.toFixed(3)); distSlider.step = dist.step;
        }
      }
      if (speed && speedSlider){
        if (unit==='km'){
          speed.min  = String(baseSpeedMin);  speedSlider.min  = String(baseSpeedMin);
          speed.max  = String(baseSpeedMax);  speedSlider.max  = String(baseSpeedMax);
          speed.step = String(baseSpeedStep); speedSlider.step = String(baseSpeedStep);
        } else {
          speed.min  = String((baseSpeedMin/ kmPerMi).toFixed(2));  speedSlider.min  = speed.min;
          speed.max  = String((baseSpeedMax/ kmPerMi).toFixed(2));  speedSlider.max  = speed.max;
          var sStep = baseSpeedStep/ kmPerMi;
          speed.step = String(sStep.toFixed(3)); speedSlider.step = speed.step;
        }
      }
    }


    var lastChanged = null; // 'pace' | 'speed' | 'time' | 'distance'

    function updateUnit(newUnit){
      unit = (newUnit==='mi') ? 'mi' : 'km';
      qsa(root, '.js-unit-distance').forEach(function(n){ n.textContent = unit; });
      qsa(root, '.js-unit-speed').forEach(function(n){ n.textContent = unit==='mi'?'mph':'km/h'; });
      applyRanges();

      // Convert current values when switching unit
      var d = parseNum(dist && dist.value);
      var pStr = pace && pace.value ? String(pace.value).trim() : '';
      var pSec = toSec(pStr);
      var v = parseNum(speed && speed.value);
      if (unit==='mi') { // switching to miles
        if (isFinite(d) && d>0) { var nd = (d / kmPerMi); dist.value = nd.toFixed(2); if (distSlider) distSlider.value = dist.value; }
        if (isFinite(pSec)) { var np = pSec*kmPerMi; if (pace) pace.value = secToMMSS(np); }
        if (isFinite(v)) { var nv = (v / kmPerMi); if (speed) speed.value = nv.toFixed(2); if (speedSlider) speedSlider.value = speed.value; }
      } else { // switching to kilometers
        if (isFinite(d) && d>0) { var nd2 = (d * kmPerMi); dist.value = nd2.toFixed(2); if (distSlider) distSlider.value = dist.value; }
        if (isFinite(pSec)) { var np2 = pSec/kmPerMi; if (pace) pace.value = secToMMSS(np2); }
        if (isFinite(v)) { var nv2 = (v * kmPerMi); if (speed) speed.value = nv2.toFixed(2); if (speedSlider) speedSlider.value = speed.value; }
      }
      applyRanges();
      recalc();
    }

    unitRadios.forEach(function(r){
      r.addEventListener('change', function(){ if (r.checked) updateUnit(r.value); });
    });

    // quick distance chips
    qsa(root, '.quick').forEach(function(btn){
      btn.addEventListener('click', function(){
        var val = parseNum(btn.getAttribute('data-distance'));
        if (unit==='mi') val = val / kmPerMi;
        if (dist) dist.value = String(val);
        if (distSlider) distSlider.value = String(val);
        lastChanged = 'distance';
        recalc();
      });
    });

    // preset chips: set distance + time
    qsa(root, '.preset').forEach(function(btn){
      btn.addEventListener('click', function(){
        var d = parseNum(btn.getAttribute('data-distance'));
        var t = btn.getAttribute('data-time'); // "hh:mm:ss"
        if (unit==='mi') d = d / kmPerMi;
        if (dist) dist.value = String(d);
        if (distSlider) distSlider.value = String(d);
        var parts = (t||'').split(':');
        if (hI) hI.value = parts[0]||'0';
        if (mI) mI.value = parts[1]||'0';
        if (sI) sI.value = parts[2]||'0';
        if (pace) pace.value = '';
        if (speed) speed.value = '';
        lastChanged = 'time';
        recalc();
      });
    });

    // sync sliders <-> inputs and track lastChanged
    if (dist && distSlider) {
      dist.addEventListener('input', function(){
        var v = parseNum(dist.value);
        if (isFinite(v)) distSlider.value = v;
        lastChanged = 'distance';
        recalc();
      });
      distSlider.addEventListener('input', function(){
        dist.value = distSlider.value;
        lastChanged = 'distance';
        recalc();
      });
    }
    if (speed && speedSlider) {
      speed.addEventListener('input', function(){
        var v = parseNum(speed.value);
        if (isFinite(v)) speedSlider.value = v;
        lastChanged = 'speed';
        recalc();
      });
      speedSlider.addEventListener('input', function(){
        speed.value = speedSlider.value;
        lastChanged = 'speed';
        recalc();
      });
    }
    if (pace) {
      pace.addEventListener('input', function(){
        lastChanged = 'pace';
        recalc();
      });
    }
    qsa(root, '[data-field="time_h"],[data-field="time_m"],[data-field="time_s"]').forEach(function(inp){
      inp.addEventListener('input', function(){
        lastChanged = 'time';
        recalc();
      });
    });

    function buildGroups(pacePerKm, Vkmh){
      if (!presetsWrap) return;
      presetsWrap.innerHTML = '';
      GROUPS.forEach(function(group){
        var frag = document.createDocumentFragment();
        var sectionTitle = document.createElement('div');
        sectionTitle.className = 'results-subtitle';
        sectionTitle.textContent = group.name;
        frag.appendChild(sectionTitle);
        var grid = document.createElement('div');
        grid.className = 'results-grid';
        group.items.forEach(function(item){
          var card = document.createElement('div');
          card.className = 'card';
          var t = document.createElement('div'); t.className='t';
          var v = document.createElement('div'); v.className='v';
          t.textContent = item.label;
          if (item.km != null && isFinite(pacePerKm)) {
            var tsec = item.km * pacePerKm;
            v.textContent = secToHHMMSS(tsec);
          } else if (item.hours != null && (isFinite(Vkmh) || isFinite(pacePerKm))) {
            var distKm = isFinite(Vkmh) ? (Vkmh * item.hours) : ((item.hours*3600) / pacePerKm);
            var display = (unit==='mi') ? (distKm/1.609344) : distKm;
            var suffix = (unit==='mi') ? ' mi' : ' km';
            v.textContent = (Math.round(display*100)/100).toFixed(2).replace('.', ',') + suffix;
          } else {
            v.textContent = '–';
          }
          card.appendChild(t); card.appendChild(v);
          grid.appendChild(card);
        });
        frag.appendChild(grid);
        presetsWrap.appendChild(frag);
      });
    }

    
function recalc(){
      setError(root, '');
      var dUser = parseNum(dist && dist.value);
      var T = toSecTriple(hI && hI.value, mI && mI.value, sI && sI.value);
      var P_in = toSec(pace && pace.value);
      var V_in = parseNum(speed && speed.value);

      // Normalize inputs to km / sec-per-km / kmh
      var D = (isFinite(dUser) && dUser>0) ? (unit==='mi' ? dUser*kmPerMi : dUser) : NaN; // km
      var haveD = isFinite(D);
      var haveT = isFinite(T);
      var haveP = isFinite(P_in);
      var haveV = isFinite(V_in);

      // pace per km internal
      var paceS = NaN;
      if (haveP) paceS = (unit==='mi') ? P_in*kmPerMi : P_in;

      // speed km/h internal
      var Vkmh = NaN;
      if (haveV) Vkmh = (unit==='mi') ? V_in*kmPerMi : V_in;

      // If both P and V given, resolve conflict by lastChanged (default: speed)
      if (haveP && haveV) {
        if (lastChanged === 'pace') {
          Vkmh = 3600 / paceS;
        } else {
          paceS = 3600 / Vkmh;
        }
      } else if (haveP && !haveV) {
        Vkmh = 3600 / paceS;
      } else if (!haveP && haveV) {
        paceS = 3600 / Vkmh;
      }

      var timeS = haveT ? T : NaN;

      // Pairwise solve: any two -> compute others
      if (isFinite(D) && isFinite(timeS)) {
        paceS = timeS / D;
        Vkmh = 3600 / paceS;
      } else if (isFinite(D) && isFinite(paceS)) {
        timeS = D * paceS;
        Vkmh = 3600 / paceS;
      } else if (isFinite(D) && isFinite(Vkmh)) {
        paceS = 3600 / Vkmh;
        timeS = D * paceS;
      } else if (isFinite(timeS) && isFinite(paceS)) {
        D = timeS / paceS;
        Vkmh = 3600 / paceS;
      } else if (isFinite(timeS) && isFinite(Vkmh)) {
        paceS = 3600 / Vkmh;
        D = timeS / paceS;
      } else if (isFinite(paceS) && isFinite(Vkmh)) {
        // Both define each other; nothing to derive for D or T
      }

      // Update outputs
      // Distance display
      if (resDistance) {
        if (isFinite(D)) {
          var Ddisp = (unit==='mi') ? (D/kmPerMi) : D;
          resDistance.textContent = Ddisp.toFixed(2) + ' ' + (unit==='mi'?'mi':'km');
        } else {
          resDistance.textContent = '–';
        }
      }

      if (resTime)     resTime.textContent     = isFinite(timeS) ? secToHHMMSS(timeS) : '–';
      if (resPace)     resPace.textContent     = isFinite(paceS) ? (secToMMSS( (unit==='mi') ? paceS*kmPerMi : paceS ) + ' min/' + (unit==='mi'?'mi':'km')) : '–';
      if (resSpeed)    resSpeed.textContent    = isFinite(Vkmh) ? ( ((unit==='mi') ? (Vkmh/kmPerMi) : Vkmh).toFixed(2) + ' ' + (unit==='mi'?'mph':'km/h')) : '–';

      // Mutually sync raw inputs where missing/derived
      if (pace && (!haveP || lastChanged==='speed')) {
        if (isFinite(paceS)) {
          var pOut = (unit==='mi') ? paceS/kmPerMi : paceS;
          pace.value = secToMMSS(pOut);
        }
      }
      if (speed && (!haveV || lastChanged==='pace')) {
        if (isFinite(Vkmh)) {
          var vOut = (unit==='mi') ? (Vkmh/kmPerMi) : Vkmh;
          speed.value = vOut.toFixed(2);
          if (speedSlider) speedSlider.value = speed.value;
        }
      }
      if (hI && mI && sI && !haveT && isFinite(timeS)) {
        var h = Math.floor(timeS/3600), m = Math.floor((timeS%3600)/60), s = Math.round(timeS%60);
        hI.value = h; mI.value = m; sI.value = s;
      }
      if (dist && distSlider && !isFinite(dUser) && isFinite(D)) {
        var dOut = (unit==='mi') ? (D/kmPerMi) : D;
        dist.value = dOut.toFixed(2);
        distSlider.value = dist.value;
      }

      // Groups always work off pace/speed even ohne Distanz/Zeit
      buildGroups(paceS, Vkmh);
    }

    // Reset-Button (bleibt)
    var btnReset = qs(root, '[data-action=\"reset\"]');
    if (btnReset) btnReset.addEventListener('click', function(e){
      e.preventDefault();
      if (dist) dist.value='';
      if (distSlider) distSlider.value = distSlider.min || '0';
      if (hI) hI.value='';
      if (mI) mI.value='';
      if (sI) sI.value='';
      if (pace) pace.value='';
      if (speed) speed.value='';
      if (speedSlider) speedSlider.value = speedSlider.min || '0';
      lastChanged = null;
      // Default preset: 10 km · 50:00
      var defBtn = qs(root, '.preset[data-distance=\"10\"][data-time=\"00:50:00\"]');
      if (defBtn) defBtn.click();
      recalc();
    });

    // Initialisieren
    var initialUnit = el(root).getAttribute('data-unit')==='mi'?'mi':'km';
    unitRadios.forEach(function(r){ r.checked = (r.value===initialUnit); });
    updateUnit(initialUnit);
    applyRanges();

    // Default Preset anwenden, damit direkt Ergebnisse sichtbar sind
    var defaultPresetBtn = qs(root, '.preset[data-distance=\"10\"][data-time=\"00:50:00\"]');
    if (defaultPresetBtn) defaultPresetBtn.click();

    // Sicherheits-Recalc beim Laden
    recalc();
  }

  function boot(){
    qsa(document, '[data-calculator]').forEach(function(root){
      var type = el(root).getAttribute('data-calculator');
      if (type === 'pace') attachPace(root);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();