<?php
namespace Pacehub\ToolsCalculatorsBundle\Module;

use Contao\Module;

class CalcTools extends Module
{
    protected $strTemplate = 'mod_calc_tools';

    protected function compile(): void
    {
        // Map DCA fields to template vars (fallbacks)
        $this->Template->calculatorType  = $this->calc_tools_type ?: 'pace';
        $this->Template->defaultDistance = (float) ($this->calc_default_distance ?: 10.0);
        $this->Template->unit            = $this->calc_unit ?: 'km';
        $this->Template->showSpeed       = (bool) $this->calc_show_speed;

        // Register assets (public/)
        $GLOBALS['TL_JAVASCRIPT']['tools_calculators'] = 'bundles/toolscalculators/tools.js|static';
        $GLOBALS['TL_CSS']['tools_calculators'] = 'bundles/toolscalculators/tools.css|static';
    }
}
