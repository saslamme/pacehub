<?php
$GLOBALS['TL_LANG']['FMD']['miscellaneous'] = 'Verschiedenes';
$GLOBALS['TL_LANG']['FMD']['calc_tools'][0] = 'Rechner (Tools)';
$GLOBALS['TL_LANG']['FMD']['calc_tools'][1] = 'Pace-, BMI- und VO₂max-Rechner als Frontend-Modul.';
