<?php

namespace Spatie\SchemaOrg\Exceptions;

use InvalidArgumentException;

class TypeAlreadyInGraph extends InvalidArgumentException
{
}
