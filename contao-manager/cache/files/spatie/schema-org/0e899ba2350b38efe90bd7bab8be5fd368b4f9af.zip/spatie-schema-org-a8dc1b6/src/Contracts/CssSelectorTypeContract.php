<?php

namespace Spatie\SchemaOrg\Contracts;

interface CssSelectorTypeContract
{
}
