<?php

return [
    'Names' => [
        'SGD' => [
            '$',
            'Singapore Dollar',
        ],
    ],
];
