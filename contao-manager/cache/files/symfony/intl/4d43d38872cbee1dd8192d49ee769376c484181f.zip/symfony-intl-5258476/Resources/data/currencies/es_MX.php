<?php

return [
    'Names' => [
        'BTN' => [
            'BTN',
            'ngultrum butanés',
        ],
        'MRO' => [
            'MRU',
            'uguiya (1973–2017)',
        ],
        'MRU' => [
            'UM',
            'uguiya mauritano',
        ],
        'MVR' => [
            'MVR',
            'rupia de Maldivas',
        ],
        'MXN' => [
            '$',
            'peso mexicano',
        ],
        'THB' => [
            'THB',
            'baht tailandés',
        ],
        'ZMW' => [
            'ZMW',
            'kwacha zambiano',
        ],
    ],
];
