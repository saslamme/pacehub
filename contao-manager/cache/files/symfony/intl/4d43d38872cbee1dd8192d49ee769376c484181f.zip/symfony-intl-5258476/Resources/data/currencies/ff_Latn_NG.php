<?php

return [
    'Names' => [
        'NGN' => [
            '₦',
            'Nayraa Nijeriyaa',
        ],
    ],
];
