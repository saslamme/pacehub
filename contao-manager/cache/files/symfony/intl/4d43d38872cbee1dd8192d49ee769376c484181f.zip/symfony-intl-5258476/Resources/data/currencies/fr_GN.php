<?php

return [
    'Names' => [
        'GNF' => [
            'FG',
            'franc guinéen',
        ],
    ],
];
