<?php

return [
    'Names' => [
        'PKR' => [
            'Rs',
            'پاکستانۍ کلداره',
        ],
    ],
];
