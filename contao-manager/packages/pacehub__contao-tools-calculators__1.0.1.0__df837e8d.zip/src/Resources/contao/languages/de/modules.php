<?php
$GLOBALS['TL_LANG']['FMD']['miscellaneous'] = 'Verschiedenes';
$GLOBALS['TL_LANG']['FMD']['calc_tools'] = ['Rechner (Tools)', 'Pace-, BMI- und VO₂max-Rechner als Frontend-Modul.'];
