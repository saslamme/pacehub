<?php
$GLOBALS['TL_LANG']['tl_module']['calc_tools_type']       = ['Rechnertyp', 'Wähle, welcher Rechner angezeigt wird.'];
$GLOBALS['TL_LANG']['tl_module']['calc_default_distance'] = ['Standard-Distanz', 'Voreinstellung z. B. 10.'];
$GLOBALS['TL_LANG']['tl_module']['calc_unit']             = ['Einheit', 'Kilometer (km) oder Meilen (mi).'];
$GLOBALS['TL_LANG']['tl_module']['calc_show_speed']       = ['Geschwindigkeit anzeigen', 'Zeigt zusätzlich km/h bzw. mph.'];
