<?php
// Register legacy frontend module (Contao 4.13)
$GLOBALS['FE_MOD']['miscellaneous']['calc_tools'] = \Pacehub\ToolsCalculatorsBundle\Module\CalcTools::class;
