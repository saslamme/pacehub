(function () {
  function isJQ(obj){ return !!(obj && obj.jquery); }
  function el(node){ return isJQ(node) ? node[0] : node; }
  function qs(root, sel){ var r = el(root); return r ? r.querySelector(sel) : null; }
  function qsa(root, sel){ var r = el(root); return r ? Array.prototype.slice.call(r.querySelectorAll(sel)) : []; }

  function toSec(hms) {
    if (!hms) return NaN;
    var parts = hms.trim().split(':').map(function(n){ return Number(n); });
    if (parts.some(function(n){ return Number.isNaN(n) || n < 0; })) return NaN;
    if (parts.length === 3) { var h = parts[0], m = parts[1], s = parts[2]; return h*3600 + m*60 + s; }
    if (parts.length === 2) { var m2 = parts[0], s2 = parts[1]; return m2*60 + s2; }
    if (parts.length === 1) { return parts[0]*60; }
    return NaN;
  }
  function secToHHMMSS(sec) {
    if (!isFinite(sec) || sec < 0) return '';
    var h = Math.floor(sec/3600);
    var m = Math.floor((sec%3600)/60);
    var s = Math.round(sec%60);
    function pad(x){ return String(x).padStart(2,'0'); }
    return [pad(h),pad(m),pad(s)].join(':');
  }
  function secToMMSS(sec) {
    if (!isFinite(sec) || sec <= 0) return '';
    var m = Math.floor(sec/60);
    var s = Math.round(sec%60);
    function pad(x){ return String(x).padStart(2,'0'); }
    return pad(m)+':'+pad(s);
  }
  function setError(root, msg) {
    var elr = qs(root, '.tools-error');
    if (!elr) return;
    if (msg) { elr.textContent = msg; elr.hidden = false; }
    else { elr.textContent = ''; elr.hidden = true; }
  }
  function formatNum(x, digits){
    digits = digits==null ? 2 : digits;
    var p = Math.pow(10,digits);
    return (Math.round(x*p)/p).toString().replace('.',',');
  }

  // clamp helper
  function clamp(v, min, max){ v = Number(v); if (!isFinite(v)) return v; if (min!=null && v<min) v=min; if (max!=null && v>max) v=max; return v; }

  // ---- Pace ----
  function attachPace(root) {
    var unit = (el(root).getAttribute('data-unit') === 'mi') ? 'mi' : 'km';
    var hasSpeed = el(root).getAttribute('data-show-speed') === '1';
    var kmPerMi = 1.609344;

    qsa(root, '.js-unit-distance').forEach(function(span){ span.textContent = unit; });
    qsa(root, '.js-unit-speed').forEach(function(span){ span.textContent = unit === 'mi' ? 'mph' : 'km/h'; });

    var dist  = qs(root, '[data-field="distance"]');
    var time  = qs(root, '[data-field="time"]');
    var pace  = qs(root, '[data-field="pace"]');
    var speed = hasSpeed ? qs(root, '[data-field="speed"]') : null;

    var distSlider  = qs(root, '[data-field="distance_slider"]');
    var speedSlider = hasSpeed ? qs(root, '[data-field="speed_slider"]') : null;

    var distanceValEl = qs(root, '.js-distance-val');
    var speedValEl    = qs(root, '.js-speed-val');

    // slider ranges in UI units
    if (distSlider) {
      distSlider.min = "0";
      distSlider.max = unit === 'mi' ? "62" : "100"; // ~100 km / 62 mi
      distSlider.step = "0.1";
    }
    if (speedSlider) {
      speedSlider.min = "0";
      speedSlider.max = unit === 'mi' ? "20" : "30"; // 0-30 km/h or 0-20 mph
      speedSlider.step = "0.1";
    }

    // default distance
    var def = parseFloat((el(root).getAttribute('data-default-distance') || '0'));
    if (dist && !dist.value && isFinite(def)) dist.value = def;

    // sync display helpers
    function renderDistanceVal(){
      if (distanceValEl && dist) distanceValEl.textContent = (dist.value || '0');
    }
    function renderSpeedVal(){
      if (!hasSpeed) return;
      if (speedValEl && speed) speedValEl.textContent = (speed.value || '0');
    }

    // sync: slider -> input
    if (distSlider && dist) {
      distSlider.addEventListener('input', function(){
        dist.value = distSlider.value;
        renderDistanceVal();
      });
    }
    if (speedSlider && speed) {
      speedSlider.addEventListener('input', function(){
        speed.value = speedSlider.value;
        renderSpeedVal();
      });
    }

    // sync: input -> slider
    if (dist && distSlider) {
      dist.addEventListener('input', function(){
        var v = parseFloat((dist.value||'').toString().replace(',','.'));
        if (isFinite(v)) distSlider.value = clamp(v, parseFloat(distSlider.min), parseFloat(distSlider.max));
        renderDistanceVal();
      });
    }
    if (hasSpeed && speed && speedSlider) {
      speed.addEventListener('input', function(){
        var v = parseFloat((speed.value||'').toString().replace(',','.'));
        if (isFinite(v)) speedSlider.value = clamp(v, parseFloat(speedSlider.min), parseFloat(speedSlider.max));
        renderSpeedVal();
      });
    }

    // initial render
    renderDistanceVal(); renderSpeedVal();
    if (distSlider && dist && dist.value) distSlider.value = dist.value;
    if (speedSlider && speed && speed.value) speedSlider.value = speed.value;

    function calc() {
      setError(root, '');
      var dUser = parseFloat((dist && dist.value || '').toString().replace(',','.'));
      if (!isFinite(dUser) || dUser <= 0) { setError(root, 'Bitte eine gültige Distanz eingeben.'); return; }

      var D = unit === 'mi' ? dUser * kmPerMi : dUser;
      var T = toSec((time && time.value || '').trim());
      var P = toSec((pace && pace.value || '').trim());
      var Vdisp = speed ? parseFloat((speed.value || '').toString().replace(',','.')) : NaN;

      var haveT = isFinite(T), haveP = isFinite(P), haveV = isFinite(Vdisp);
      if ((haveT?1:0) + (haveP?1:0) + (haveV?1:0) < 1) { setError(root, 'Bitte mindestens zwei Felder ausfüllen.'); return; }

      var timeS = T, paceS = P, Vkmh = (unit === 'mi' && haveV) ? Vdisp*kmPerMi : Vdisp;

      if (haveT && haveP) {
        var pacePerKm1 = unit === 'mi' ? (paceS / kmPerMi) : paceS;
        if (pacePerKm1 <= 0) { setError(root, 'Ungültige Eingaben.'); return; }
        Vkmh = 3600 / pacePerKm1;
      } else if (haveT && haveV) {
        var pacePerKm2 = 3600 / Vkmh;
        paceS = unit === 'mi' ? pacePerKm2 * kmPerMi : pacePerKm2;
      } else if (haveP && haveV) {
        var pacePerKm3 = unit === 'mi' ? (paceS / kmPerMi) : paceS;
        var ok = Math.abs(3600/pacePerKm3 - Vkmh) < 1e-6;
        if (!ok) { setError(root, 'Pace und Geschwindigkeit passen nicht zusammen.'); return; }
      } else if (haveT) {
        var pacePerKm4 = timeS / D;
        if (pacePerKm4 <= 0) { setError(root, 'Ungültige Eingaben.'); return; }
        paceS = unit === 'mi' ? pacePerKm4 * kmPerMi : pacePerKm4;
        Vkmh = 3600 / pacePerKm4;
      } else if (haveP) {
        var pacePerKm5 = unit === 'mi' ? (paceS / kmPerMi) : paceS;
        timeS = D * pacePerKm5;
        Vkmh = 3600 / pacePerKm5;
      } else if (haveV) {
        var pacePerKm6 = 3600 / Vkmh;
        paceS = unit === 'mi' ? pacePerKm6 * kmPerMi : pacePerKm6;
        timeS = D * pacePerKm6;
      }

      if (!isFinite(paceS) || paceS <= 0) { setError(root, 'Ungültige Pace.'); return; }
      var paceOut = secToMMSS(paceS);
      var Vout = unit === 'mi' ? (Vkmh / kmPerMi) : Vkmh;

      if (pace && !haveP) pace.value = paceOut;
      if (time && !haveT) time.value = secToHHMMSS(timeS);
      if (speed && !haveV) speed.value = formatNum(Vout, 2);

      // reflect back to sliders and badges
      if (distSlider && dist) distSlider.value = dist.value;
      if (speedSlider && speed) speedSlider.value = (speed.value || '');
      renderDistanceVal(); renderSpeedVal();
    }

    var btnCalc  = qs(root, '[data-action="calc"]');
    var btnReset = qs(root, '[data-action="reset"]');
    if (btnCalc)  btnCalc.addEventListener('click', calc);
    if (btnReset) btnReset.addEventListener('click', function(){
      [dist, time, pace, speed].forEach(function(i){ if(i) i.value=''; });
      if (distSlider) distSlider.value = distSlider.min || "0";
      if (speedSlider) speedSlider.value = speedSlider.min || "0";
      renderDistanceVal(); renderSpeedVal();
      setError(root, '');
    });
  }

  // ---- BMI ----
  function attachBMI(root) {
    var h = qs(root, '[data-field="height_cm"]');
    var w = qs(root, '[data-field="weight_kg"]');
    var bmi = qs(root, '[data-field="bmi"]');
    function calc() {
      setError(root, '');
      var cm = parseFloat((h && h.value || '').replace(',','.'));
      var kg = parseFloat((w && w.value || '').replace(',','.'));
      if (!isFinite(cm) || cm <= 0 || !isFinite(kg) || kg <= 0) { setError(root, 'Bitte gültige Werte eingeben.'); return; }
      var m = cm / 100;
      var val = kg / (m * m);
      if (bmi) bmi.value = formatNum(val, 1);
    }
    var b1 = qs(root, '[data-action="calc"]');
    var b2 = qs(root, '[data-action="reset"]');
    if (b1) b1.addEventListener('click', calc);
    if (b2) b2.addEventListener('click', function(){ [h,w,bmi].forEach(function(i){ if(i) i.value=''; }); setError(root,''); });
  }

  // ---- VO2max ----
  function attachVO2(root) {
    var method = qs(root, '[data-field="method"]');
    var wrapCooper = qs(root, '[data-method="cooper"]');
    var wrap15mi = qs(root, '[data-method="onepoint5mi"]');
    var cooper_m = qs(root, '[data-field="cooper_m"]');
    var t15 = qs(root, '[data-field="onepoint5_time"]');
    var out = qs(root, '[data-field="vo2max"]');

    function switchMethod() {
      if (!method) return;
      var m = method.value;
      if (wrapCooper) wrapCooper.hidden = m !== 'cooper';
      if (wrap15mi) wrap15mi.hidden = m !== 'onepoint5mi';
      if (out) out.value = ''; setError(root, '');
    }
    if (method) { method.addEventListener('change', switchMethod); switchMethod(); }

    function calc() {
      setError(root, '');
      var val = NaN;
      if (method && method.value === 'cooper') {
        var d = parseFloat((cooper_m && cooper_m.value || '').replace(',','.'));
        if (!isFinite(d) || d <= 0) { setError(root, 'Bitte Distanz in Metern angeben.'); return; }
        val = (d - 504.9) / 44.73;
      } else {
        var sec = toSec((t15 && t15.value || '').trim());
        if (!isFinite(sec) || sec <= 0) { setError(root, 'Bitte gültige Zeit eingeben.'); return; }
        var min = sec / 60;
        val = 3.5 + (483 / min);
      }
      if (!isFinite(val) || val <= 0) { setError(root, 'Berechnung fehlgeschlagen.'); return; }
      if (out) out.value = formatNum(val, 1);
    }
    var b1 = qs(root, '[data-action="calc"]');
    var b2 = qs(root, '[data-action="reset"]');
    if (b1) b1.addEventListener('click', calc);
    if (b2) b2.addEventListener('click', function(){ [cooper_m, t15, out].forEach(function(i){ if(i) i.value=''; }); setError(root,''); });
  }

  function boot(){
    qsa(document, '[data-calculator]').forEach(function(root){
      var type = el(root).getAttribute('data-calculator');
      if      (type === 'pace')  attachPace(root);
      else if (type === 'bmi')   attachBMI(root);
      else if (type === 'vo2max')attachVO2(root);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();