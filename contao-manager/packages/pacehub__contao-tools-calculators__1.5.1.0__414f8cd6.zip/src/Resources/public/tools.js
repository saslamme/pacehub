(function () {
  function isJQ(obj){ return !!(obj && obj.jquery); }
  function el(node){ return isJQ(node) ? node[0] : node; }
  function qs(root, sel){ var r = el(root); return r ? r.querySelector(sel) : null; }
  function qsa(root, sel){ var r = el(root); return r ? Array.prototype.slice.call(r.querySelectorAll(sel)) : []; }

  function toSecTriple(h,m,s){
    h = Number(h||0); m = Number(m||0); s = Number(s||0);
    if ([h,m,s].some(function(x){return !isFinite(x) || x<0;})) return NaN;
    return h*3600 + m*60 + s;
  }
  function toSec(hms) {
    if (!hms) return NaN;
    var parts = hms.trim().split(':').map(function(n){ return Number(n); });
    if (parts.some(function(n){ return Number.isNaN(n) || n < 0; })) return NaN;
    if (parts.length === 3) { var h = parts[0], m = parts[1], s = parts[2]; return h*3600 + m*60 + s; }
    if (parts.length === 2) { var m2 = parts[0], s2 = parts[1]; return m2*60 + s2; }
    if (parts.length === 1) { return parts[0]*60; }
    return NaN;
  }
  function secToHHMMSS(sec) {
    if (!isFinite(sec) || sec < 0) return '';
    var h = Math.floor(sec/3600);
    var m = Math.floor((sec%3600)/60);
    var s = Math.round(sec%60);
    function pad(x){ return String(x).padStart(2,'0'); }
    return [pad(h),pad(m),pad(s)].join(':');
  }
  function secToMMSS(sec) {
    if (!isFinite(sec) || sec <= 0) return '';
    var m = Math.floor(sec/60);
    var s = Math.round(sec%60);
    function pad(x){ return String(x).padStart(2,'0'); }
    return pad(m)+':'+pad(s);
  }
  function setError(root, msg) {
    var elr = qs(root, '.tools-error');
    if (!elr) return;
    if (msg) { elr.textContent = msg; elr.hidden = false; }
    else { elr.textContent = ''; elr.hidden = true; }
  }
  function parseNum(val){ return parseFloat((val||'').toString().replace(',','.')); }

  var GROUPS = [
    { name: 'Kurze Distanzen', items: [
      {label:'400 m', km:0.4},
      {label:'800 m', km:0.8},
      {label:'1 km',  km:1},
      {label:'2 km',  km:2},
      {label:'3 km',  km:3}
    ]},
    { name: 'Mittlere Distanzen', items: [
      {label:'5 km', km:5},
      {label:'10 km', km:10},
      {label:'15 km', km:15},
      {label:'10 Meilen', km:16.09344}
    ]},
    { name: 'Lange Distanzen', items: [
      {label:'20 km', km:20},
      {label:'Halbmarathon', km:21.0975},
      {label:'25 km', km:25},
      {label:'30 km', km:30},
      {label:'Marathon', km:42.195}
    ]},
    { name: 'Ultra Läufe', items: [
      {label:'50 km', km:50},
      {label:'60 km', km:60},
      {label:'80 km', km:80},
      {label:'100 km', km:100}
    ]},
    { name: 'Stunden Läufe', items: [
      {label:'1 Stunde', hours:1},
      {label:'2 Stunden', hours:2},
      {label:'3 Stunden', hours:3},
      {label:'6 Stunden', hours:6},
      {label:'12 Stunden', hours:12},
      {label:'24 Stunden', hours:24}
    ]}
  ];

  function attachPace(root) {
    var unitRadios = qsa(root, 'input[name="unit"][data-field="unit"]');
    var unit = 'km';
    var kmPerMi = 1.609344;

    var dist  = qs(root, '[data-field="distance"]');
    var distSlider = qs(root, '[data-field="distance_slider"]');
    var hI    = qs(root, '[data-field="time_h"]');
    var mI    = qs(root, '[data-field="time_m"]');
    var sI    = qs(root, '[data-field="time_s"]');
    var pace  = qs(root, '[data-field="pace"]');
    var speed = qs(root, '[data-field="speed"]');
    var speedSlider = qs(root, '[data-field="speed_slider"]');

    var resDistance = qs(root, '.js-res-distance');
    var resTime     = qs(root, '.js-res-time');
    var resPace     = qs(root, '.js-res-pace');
    var resSpeed    = qs(root, '.js-res-speed');
    var presetsWrap = qs(root, '.js-presets');

    function updateUnit(newUnit){
      unit = (newUnit==='mi') ? 'mi' : 'km';
      qsa(root, '.js-unit-distance').forEach(function(n){ n.textContent = unit; });
      qsa(root, '.js-unit-speed').forEach(function(n){ n.textContent = unit==='mi'?'mph':'km/h'; });

      var d = parseNum(dist && dist.value);
      if (isFinite(d) && d>0){
        if (unit==='mi') dist.value = (d / kmPerMi).toFixed(2);
        else dist.value = (d * kmPerMi).toFixed(2);
        if (distSlider) distSlider.value = dist.value;
      }
      if (distSlider){ distSlider.max = (unit==='mi') ? "62" : "100"; }
      if (speedSlider){ speedSlider.max = (unit==='mi') ? "20" : "30"; }
      recalc();
    }

    unitRadios.forEach(function(r){
      r.addEventListener('change', function(){ if (r.checked) updateUnit(r.value); });
    });

    qsa(root, '.quick').forEach(function(btn){
      btn.addEventListener('click', function(){
        var val = parseNum(btn.getAttribute('data-distance'));
        if (unit==='mi') val = val / kmPerMi;
        if (dist) dist.value = String(val);
        if (distSlider) distSlider.value = String(val);
        recalc();
      });
    });

    qsa(root, '.preset').forEach(function(btn){
      btn.addEventListener('click', function(){
        var d = parseNum(btn.getAttribute('data-distance'));
        var t = btn.getAttribute('data-time');
        if (unit==='mi') d = d / kmPerMi;
        if (dist) dist.value = String(d);
        if (distSlider) distSlider.value = String(d);
        var parts = (t||'').split(':');
        if (hI) hI.value = parts[0]||'0';
        if (mI) mI.value = parts[1]||'0';
        if (sI) sI.value = parts[2]||'0';
        if (pace) pace.value = '';
        if (speed) speed.value = '';
        recalc();
      });
    });

    if (dist && distSlider) {
      dist.addEventListener('input', function(){
        var v = parseNum(dist.value);
        if (isFinite(v)) distSlider.value = v;
      });
      distSlider.addEventListener('input', function(){
        dist.value = distSlider.value;
        recalc();
      });
    }
    if (speed && speedSlider) {
      speed.addEventListener('input', function(){
        var v = parseNum(speed.value);
        if (isFinite(v)) speedSlider.value = v;
        recalc();
      });
      speedSlider.addEventListener('input', function(){
        speed.value = speedSlider.value;
        recalc();
      });
    }

    function buildGroups(pacePerKm, Vkmh){
      if (!presetsWrap) return;
      presetsWrap.innerHTML = '';
      GROUPS.forEach(function(group){
        var frag = document.createDocumentFragment();
        var sectionTitle = document.createElement('div');
        sectionTitle.className = 'results-subtitle';
        sectionTitle.textContent = group.name;
        frag.appendChild(sectionTitle);
        var grid = document.createElement('div');
        grid.className = 'results-grid';
        group.items.forEach(function(item){
          var card = document.createElement('div');
          card.className = 'card';
          var t = document.createElement('div'); t.className='t';
          var v = document.createElement('div'); v.className='v';
          t.textContent = item.label;
          if (item.km != null && isFinite(pacePerKm)) {
            var tsec = item.km * pacePerKm;
            v.textContent = secToHHMMSS(tsec);
          } else if (item.hours != null && (isFinite(Vkmh) || isFinite(pacePerKm))) {
            var distKm = isFinite(Vkmh) ? (Vkmh * item.hours) : ((item.hours*3600) / pacePerKm);
            var display = (unit==='mi') ? (distKm/1.609344) : distKm;
            var suffix = (unit==='mi') ? ' mi' : ' km';
            v.textContent = (Math.round(display*100)/100).toFixed(2).replace('.', ',') + suffix;
          } else {
            v.textContent = '–';
          }
          card.appendChild(t); card.appendChild(v);
          grid.appendChild(card);
        });
        frag.appendChild(grid);
        presetsWrap.appendChild(frag);
      });
    }

    function recalc(){
      setError(root, '');
      var dUser = parseNum(dist && dist.value);
      var T = toSecTriple(hI && hI.value, mI && mI.value, sI && sI.value);
      var P = toSec(pace && pace.value);
      var Vdisp = parseNum(speed && speed.value);

      var D = (!isFinite(dUser) || dUser<=0) ? NaN : (unit==='mi' ? dUser*kmPerMi : dUser);
      var haveD = isFinite(D);
      var haveT = isFinite(T);
      var haveP = isFinite(P);
      var haveV = isFinite(Vdisp);

      var timeS = T, paceS = P, Vkmh = (unit==='mi' && haveV) ? Vdisp*kmPerMi : Vdisp;

      if (haveD && haveT) {
        var pacePerKm = timeS / D;
        paceS = pacePerKm;
        Vkmh = 3600 / pacePerKm;
      } else if (haveD && haveP) {
        var pacePerKm2 = paceS;
        timeS = D * pacePerKm2;
        Vkmh = 3600 / pacePerKm2;
      } else if (haveD && haveV) {
        var pacePerKm3 = 3600 / Vkmh;
        timeS = D * pacePerKm3;
        paceS = pacePerKm3;
      }

      if (resDistance) resDistance.textContent = haveD ? ( (unit==='mi'? (D/ kmPerMi).toFixed(2) : D.toFixed(2)) +' '+unit) : '–';
      if (resTime)     resTime.textContent     = isFinite(timeS) ? secToHHMMSS(timeS) : '–';
      if (resPace)     resPace.textContent     = isFinite(paceS) ? (secToMMSS(unit==='mi' ? paceS*kmPerMi : paceS) + ' min/'+unit) : '–';
      if (resSpeed)    resSpeed.textContent    = isFinite(Vkmh) ? ( (unit==='mi' ? (Vkmh/kmPerMi).toFixed(2) : Vkmh.toFixed(2)) + ' ' + (unit==='mi'?'mph':'km/h')) : '–';

      if (pace && !haveP && isFinite(paceS)) pace.value = secToMMSS(unit==='mi' ? paceS*kmPerMi : paceS);
      if (speed && !haveV && isFinite(Vkmh)) speed.value = (unit==='mi' ? (Vkmh/kmPerMi).toFixed(2) : Vkmh.toFixed(2));
      if (hI && mI && sI && !haveT && isFinite(timeS)) {
        var h = Math.floor(timeS/3600), m = Math.floor((timeS%3600)/60), s = Math.round(timeS%60);
        hI.value = h; mI.value = m; sI.value = s;
      }

      buildGroups(paceS, Vkmh);
    }

    var initialUnit = el(root).getAttribute('data-unit')==='mi'?'mi':'km';
    unitRadios.forEach(function(r){ r.checked = (r.value===initialUnit); });
    updateUnit(initialUnit);
    // Buttons: Berechnen / Zurücksetzen
    var btnCalc  = qs(root, '[data-action="calc"]');
    var btnReset = qs(root, '[data-action="reset"]');
    if (btnCalc)  btnCalc.addEventListener('click', function(e){ e.preventDefault(); recalc(); });
    if (btnReset) btnReset.addEventListener('click', function(e){
      e.preventDefault();
      if (dist) { dist.value=''; }
      if (distSlider) { distSlider.value = distSlider.min || '0'; }
      if (hI) hI.value='';
      if (mI) mI.value='';
      if (sI) sI.value='';
      if (pace) pace.value='';
      if (speed) speed.value='';
      if (speedSlider) speedSlider.value = speedSlider.min || '0';
      // apply default preset again so users see something
      var defBtn = qs(root, '.preset[data-distance="10"][data-time="00:50:00"]');
      if (defBtn) defBtn.click();
      recalc();
    });


    // Default preset: 10 km in 50:00
    var defaultPresetBtn = qs(root, '.preset[data-distance="10"][data-time="00:50:00"]');
    if (defaultPresetBtn) defaultPresetBtn.click();

    qsa(root, 'input').forEach(function(inp){
      inp.addEventListener('input', function(){ recalc(); });
      inp.addEventListener('change', function(){ recalc(); });
    });
  }

  function boot(){
    qsa(document, '[data-calculator]').forEach(function(root){
      var type = el(root).getAttribute('data-calculator');
      if (type === 'pace') attachPace(root);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();