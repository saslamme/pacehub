<?php
$GLOBALS['TL_LANG']['tl_module']['calc_tools_type'][0] = 'Rechnertyp';
$GLOBALS['TL_LANG']['tl_module']['calc_tools_type'][1] = 'Wähle, welcher Rechner angezeigt wird.';
GLOBALS['TL_LANG']['tl_module']['calc_default_distance'][0] = 'Standard-Distanz';
$GLOBALS['TL_LANG']['tl_module']['calc_default_distance'][1] = 'Voreinstellung z. B. 10.';
$GLOBALS['TL_LANG']['tl_module']['calc_unit'][0] = 'Einheit';
$GLOBALS['TL_LANG']['tl_module']['calc_unit'][1] = 'Kilometer (km) oder Meilen (mi).';
$GLOBALS['TL_LANG']['tl_module']['calc_show_speed'][0] = 'Geschwindigkeit anzeigen';
$GLOBALS['TL_LANG']['tl_module']['calc_show_speed'][1] = 'Zeigt zusätzlich km/h bzw. mph.';
